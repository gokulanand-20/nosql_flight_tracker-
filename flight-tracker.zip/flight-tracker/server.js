const express = require('express');
const path = require('path');
const { MongoClient } = require('mongodb');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;
const uri = 'mongodb://127.0.0.1:27017'; // Use the correct MongoDB URI
let client;

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB once
async function connectDB() {
    try {
        client = new MongoClient(uri);
        await client.connect();
        console.log("Connected to MongoDB");
    } catch (error) {
        console.error('MongoDB connection error:', error);
        process.exit(1); // terminate the app if the DB connection fails
    }
}

// Store flight details in MongoDB
app.post('/api/flights', async (req, res) => {
    const flightDetails = req.body;
    try {
        const database = client.db('flight_tracker');
        const collection = database.collection('flights');
        const result = await collection.insertOne(flightDetails);
        res.status(201).json(result);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to save flight details' });
    }
});

// Retrieve flight details by airline and flight number
app.get('/api/flights', async (req, res) => {
    const { airline, flightNumber } = req.query;
    try {
        const database = client.db('flight_tracker');
        const collection = database.collection('flights');
        const flightDetails = await collection.findOne({ Airline: airline, FlightNumber: flightNumber });

        if (!flightDetails) {
            return res.status(404).json({ error: 'Flight not found' });
        }

        res.status(200).json(flightDetails);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to retrieve flight details' });
    }
});

// Render the flight tracker page
app.get('/', (req, res) => {
    res.render('index');
});

// Render flight details page
app.get('/flightDetails', (req, res) => {
    res.render('flights_details');
});

// Start the server
connectDB().then(() => {
    app.listen(port, () => {
        console.log(`Server is running on http://localhost:${port}`);
    });
});